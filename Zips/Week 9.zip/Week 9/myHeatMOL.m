function [t,sol] = myHeatMOL(N,tol, xspan,tspan,IC,BC)

% solves heat equation with Dirichlet BCs by MOL
global x B1 B2;

x=linspace(xspan(1),xspan(2),N+1);

uu=IC(x);
u0=uu(2:N)'; % don't need BCs
B1=BC(1); B2=BC(2);
u0;
opts=odeset('RelTol',tol);
 [t,sol]= ode15s(@heatEq,tspan,u0,opts);
% [t,sol]= ode45(@heatEq,tspan,u0,opts);
M=length(t);
sol=[B1*ones(M,1) sol B2*ones(M,1)];
solFinal = sol(:,end);

return

% ----------------------------------------------
function dUdt=heatEq(t,U);

global x B1 B2;
% U,dUdt are a column vectors;  t not used
neq=length(U); 
dx=x(2)-x(1); 
nu = 1/(dx*dx); 
dUdt=zeros(neq,1);
dUdt(1)=nu*B1-2*nu*U(1)+nu*U(2);
for k=2:neq-1
   dUdt(k)=nu*U(k-1)-2*nu*U(k)+nu*U(k+1);
end
dUdt(neq)=nu*U(neq-1)-2*nu*U(neq)+nu*B2;