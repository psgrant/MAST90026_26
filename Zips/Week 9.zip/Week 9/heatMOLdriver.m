function heatMOLdriver()
close all

N=80;
tol=1e-5;

xspan = [0 1];
tspan = [0 0.2];
BC =  [0 2];


B1=BC(1); B2=BC(2);
  
x=linspace(xspan(1),xspan(2),N+1);

IC = @(x) sin(pi*x)+B1+(B2-B1)*x;

% BC =  [0 0];

[t,sol] = myHeatMOL(N,tol,xspan,tspan,IC,BC);
exact =  exp(-pi^2*t)*(sin(pi*x)+B1+(B2-B1)*x);
size(exact);
error = abs(sol-exact);

mesh(x,t,sol)
xlabel('x')
ylabel('t')
figure
mesh(x,t,error)
xlabel('x')
ylabel('t')

finalError = error(end,:);
maxError = max(max(error))
% plot(x,finalError);