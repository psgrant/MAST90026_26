% modified from Trefethen's p6

N=256; % a power of 2
h=2*pi/N; x=h*(1:N);
t=0.2;
c=5;
v=exp(-40*(x-2).^2);
k=[0:N/2-1 0 -N/2+1:-1];

v_hat=fft(v);

%  advection
figure(1);
vnew=real(ifft(exp(-1i*c*k*t).*v_hat));
plot(x,v,x,vnew);
xlabel('x'); ylabel('u');
title('advection');
legend('t=0','t=0.2');

% diffusion

figure(2);
vnew=real(ifft(exp(-k.^2*t).*v_hat));
plot(x,v,x,vnew);
xlabel('x'); ylabel('u');
title('diffusion');
legend('t=0','t=0.2');
% dispersion

figure(3);
t=0.002;
vnew=real(ifft(exp(-1i*k.^3*t).*v_hat));
plot(x,v,x,vnew);
xlabel('x'); ylabel('u');
title('dispersion');
legend('t=0','t=0.002');
% Schrodinger

figure(4);
t=0.02;
vnew=real(ifft(exp(1i*k.^2*t).*v_hat));
plot(x,v,x,vnew);
xlabel('x'); ylabel('u');
title('Schrodinger');
legend('t=0','t=0.02');
