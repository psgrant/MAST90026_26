% Code to solve u'' = 1 st u(0)=0=u(1).
clear 
close all

N=2; % Number of intevals
x=linspace(0,1,N+1);
h=x(2)-x(1);

A=diag(2/h*ones(1,N+1)) + ...
  diag(-1/h*ones(1,N),1) + ...
  diag(-1/h*ones(1,N),-1);

f= h*ones(N+1,1);

% Apply BCS
A(1,:) = 0;
A(1,1) = 1;
A(end,:) = 0;
A(end,end) = 1;
f(1) = 0;
f(end) = 0;

u=A\f;

plot(x,u,'ro',x,0.5*x.*(1-x),'b')