function splineRunge(arg)
%splineRunge  Runge's polynomial interpolation example.
%   F(x) = 1/(1+25*x^2)
%   Cubic spline interpolation at equally spaced points, -1 <= x <= 1.
%   Does interpolant converge as number of points is increased?

F = inline('1./(1+25*x.^2)');

if nargin == 0

   % Initialize plot and uicontrols

   shg
   clf reset
   set(gcf,'doublebuffer','on','numbertitle','off', ...
       'name','Runge''s interpolation example by spline')
   %n = 1;
   n=3;
   u = -1.1:.01:1.1;
   z = F(u);
   h.plot = plot(u,z,'-', 0,1,'o', u,z,'-');
   set(h.plot(1),'color',[.6 .6 .6]);
   set(h.plot(2),'color','blue');
   set(h.plot(3),'color',[0 2/3 0]);
   axis([-1.1 1.1 -0.1 1.1])
   title(char(F),'interpreter','none')

   h.minus = uicontrol('units','norm','pos',[.38 .01 .06 .05], ...
          'fontsize',12,'string','<','callback','splineRunge(''n--'')');
   h.n = uicontrol('units','norm','pos',[.46 .01 .12 .05], ...
          'fontsize',12,'userdata',n,'callback','splineRunge(''n=3'')');
   h.plus = uicontrol('units','norm','pos',[.60 .01 .06 .05], ...
          'fontsize',12,'string','>','callback','splineRunge(''n++'')');
   h.close = uicontrol('units','norm','pos',[.80 .01 .10 .05], ...
          'fontsize',12,'string','close','callback','close');

   set(gcf,'userdata',h)
   arg = 'n=3';
end

% Update plot.

h = get(gcf,'userdata');

% Number of interpolation points.

n = get(h.n,'userdata');

switch arg
   case 'n--', n = n-2;
   case 'n++', n = n+2;
   case 'n=3', n = 3;
end
set(h.n,'string',['n = ' num2str(n)],'userdata',n);
if n==3
   set(h.minus,'enable','off');
else
   set(h.minus,'enable','on');
end

if n == 3;
   x = [-1 0 1];
else
   x = -1 + 2*(0:n-1)/(n-1);
end
y = F(x);
u = get(h.plot(1),'xdata');

v = spline(x,y,u);

set(h.plot(2),'xdata',x,'ydata',y);
set(h.plot(3),'xdata',u,'ydata',v);

