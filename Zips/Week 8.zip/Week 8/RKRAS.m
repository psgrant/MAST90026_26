%
% function RKRAS( p , scale )
%
% For a fixed value of p, this plots the region of absolute stability 
% for explicit RKp, 1<=p<=4. The result is plotted on the square 
% [-scale,scale] x [-scale,scale]
%
% For instance, try RKRAS( 4 , 3 );
%
% This uses a primitive method of laying out a 301 x 301 grid 
% and checking to see if the inequality 
%
% | P(z) | < 1
%
% is satisfied at each point in the grid. This is to demonstrate a 
% technique of investigation; if you can't quite find the region, 
% try a straight implementation to give you some insight into the problem.
%
% Adapted from CheckRAS by Paul Macklin
% pmacklin@math.uci.edu.NOSPAM
% http://math.uci.edu/~pmacklin
%
% 5-14-2005
%
% by SLC 15-05-2006

function RKRAS( p , scale );

if (p<1 |p>4)
   disp('p must be  1-4') 
   return
end
M = 301;
N = 301;
Points = zeros(M,N);
X = linspace(-scale,scale,M);
Y = linspace(-scale,scale,N);

for i=1:M
    for j=1:M
        Points(i,j) = CheckTruth(X(i),Y(j),p);
    end
end

COLORMAP = [[1,1,1];[0,0,1]];

figure(1);
contourf(X,Y,Points',[0.5 0.5]);
hold on;
plot(X,zeros(size(X)),'k');
plot(zeros(size(Y)),Y,'k');
hold off;
colormap(COLORMAP);

axis image;
axis([X(1),X(M),Y(1),Y(N)]);

title(sprintf('Region of Absolute Stability for RK%1d',p));
xlabel('x');
ylabel('y');
figure(1);




function out = CheckTruth(x,y,p)
 out = 0.0;
switch p
    case 1,
        realFact=1+x;
        imagFact=y;
    case 2,
        realFact = 1+x +(x^2-y^2)/2;
        imagFact = y+x*y;
    case 3,
        realFact = 1+x +(x^2-y^2)/2+(x^3-3*x*y^2)/6;
        imagFact = y+x*y+(3*x^2*y-y^3)/6;
    case 4,
        realFact = 1+x +(x^2-y^2)/2+(x^3-3*x*y^2)/6+(x^4-6*x^2*y^2+y^4)/24;
        imagFact = y+x*y+(3*x^2*y-y^3)/6+(4*x^3*y-4*x*y^3)/24;
    otherwise
        
end
% LeftDistance = sqrt( (x-LeftX)^2 + y^2 );
% RightDistance = sqrt( (x-RightX)^2 + y^2 );
% LeftDistance = sqrt(  (1 + (1-theta)*x)^2 + ((1-theta)*y)^2 );
% RightDistance = sqrt( (1 - theta*x)^2 + (theta*y)^2 ); 
% if( LeftDistance < Factor*RightDistance )
if( (realFact^2+imagFact^2) < 1 )
     out = 1.0;
 end
 