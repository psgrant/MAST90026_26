% Solve the nonsteady heat equation using finite diference scheme.

clear; close all;

theta=0.25;
N=50;                                          % number of grid points
nu=1.1;
dx=1/N;                                        % space step
dt=nu*dx^2;                                    % time step

col=ones(N-1,1);                               % column vector of ones
D=spdiags([col -2*col col],[-1,0,1],N-1,N-1);  % second difference matrix
A=spdiags(col,0,N-1,N-1)-theta*nu*D;           % LHS matrix
B=spdiags(col,0,N-1,N-1)+(1-theta)*nu*D;       % RHS matrix

x=(0:dx:1)';                                   % grid points
ue=sin(pi*x);                                  % initial data
u=ue(2:N);                                     % remove boundary values

for t=dt:dt:1
  u=A\ (B*u);                                  % update solution
  ue=sin(pi*x)*exp(-pi*pi*t);                  % compute exact solution
  if mod(t,0.05) < dt                          % at intervals of 0.05
    plot(x,[0;u;0],x,ue,'r'); drawnow;         % plot current solution
  end
end