% Solve advection equation using an explicit upwind method

N=50;                       % number of space steps
nu=0.6;                     % CFL number
dx=1/N;                     % mesh spacing
dt=nu*dx;                   % time step

% initialisation
x=(0:dx:1)';                % grid points for numerical solution
xx=(0:dx/10:1)';            % finer grid for analytical solution
ue=max(0,1-5*abs(xx-0.4));  % initial data
U=max(0,1-5*abs(x-0.4));
plot(x,U)
drawnow
hold on
J=2:N+1;                    % set of points to update at

for t=dt:dt:0.4
  U(J)=U(J)-nu*(U(J)-U(J-1));  % update solution
  ue=max(0,1-5*abs(xx-t-0.4));
  if mod(t,4*dt)<dt
    plot(x,U,xx,ue,'r'); drawnow;
  end
end
hold off