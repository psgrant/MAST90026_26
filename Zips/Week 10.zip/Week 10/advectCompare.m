% Solution  of the advection equation
%
%    u_t + a*u_x = 0
%
% x \in I=[a,b]  and  t \in [0,T] with the 
% initial data  u(x,0) = u_0(x) with different methods
%   FTCS  (unstable)
%   Lax-Friedrichs
%   Lax-Wendroff
%   Upwind
%
% adapted by SLC 6/5/07 from 
% transport.m by 
% Author     : Stefan H�eber
% Date       : January 30, 2003
% Institution: University of Stuttgart,
%              Institut for Applied Analysis and Numerical Mathematics,
%              Numerical Mathematics for super computers  
% Version    : 1.0


clear all; close all;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Parameters 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% velocity
a = 1;


% Initial data
% u0 = inline('sin(pi*x)');
% u0= @(x) exp(-20*(x-1).^2);
u0=@(x)(1+sign(x-0.8))/2-(1+sign(x-1.2))/2;
% exact solution for computing the error
% u0T = 'sin(pi*(x-a*T))';
% exact = @(x,t) exp(-20*(x-1-a*t).^2);
exact = @(x,t) (1+sign(x-0.8-a*t))/2-(1+sign(x-1.2-a*t))/2;



% Time/space Intervals 
T = 0.5;
I = [0 2];

% Number of time steps
TT(1) = 100;  % was 700
% Number of space steps
XX(1) = 200;




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% menu
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
flag = menu('Please select a method',...
						'FTCS',...
						'Lax-Friedrichs',...
						'Lax-Wendroff',...
						'Upwind');

disp('Please wait ...');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FTCS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  if flag==1       
        NT=TT(1);
        NX=XX(1);
        		
		dt = T/NT;
		dx = (I(2)-I(1))/NX;
		% lambda = dt/dx;
        meshrat=dt/dx;
        courant=a*dt/dx
		
		% Initial conditions
		SOL = zeros(NX+2*NT+1,2);
		SOLPLOT = zeros(NX+1,NT+1);
		for j = 1:NX+2*NT+1
			SOL(j,1) = u0(I(2)+(NT+1-j)*dx);
		end
		SOLPLOT(:,1) = SOL(NT+1:NT+NX+1,1);
		
		% Finite Difference-Scheme: FTCS
		for n = 1:NT
			for j = 1+n:NX+2*NT+1-n
				% SOL(j,2) = SOL(j,1) - 0.5*lambda*a*(SOL(j-1,1)-SOL(j+1,1));
                SOL(j,2) = SOL(j,1) - 0.5*courant*(SOL(j+1,1)-SOL(j-1,1));
			end
		SOL(:,1) = SOL(:,2);
		SOLPLOT(:,n+1) = SOL(NT+1:NT+NX+1,1);
        end
	
		xx = linspace(I(1),I(2),NX+1);
        
		time = ones(NX+1,1)*linspace(0,T,NT+1);
		space = linspace(I(2),I(1),NX+1)'*ones(1,NT+1);
        plot(xx,SOLPLOT(:,1),xx,SOLPLOT(:,NT+1),xx,exact(xx,T));
        xlabel('x'); ylabel('u'); legend('initial', 'FTCS','exact');
        title(['FTCS for courant = ',num2str(courant)]);
        pause(0.5);
		
end
	



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Lax-Friedrichs
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if flag==2       
        NT=TT(1);
        NX=XX(1);
        		
		dt = T/NT;
		dx = (I(2)-I(1))/NX;
		% lambda = dt/dx;
        meshrat=dt/dx;
        courant=a*dt/dx
		
		% Initial conditions
		SOL = zeros(NX+2*NT+1,2);
		SOLPLOT = zeros(NX+1,NT+1);
		for j = 1:NX+2*NT+1
			SOL(j,1) = u0(I(2)+(NT+1-j)*dx);
		end
		SOLPLOT(:,1) = SOL(NT+1:NT+NX+1,1);
		
		% Finite Difference-Scheme: Lax-Friedrichs
		for n = 1:NT
			for j = 1+n:NX+2*NT+1-n
				% SOL(j,2) = 0.5*(SOL(j-1,1)+SOL(j+1,1)) - 0.5*lambda*a*(SOL(j-1,1)-SOL(j+1,1));
                SOL(j,2) = 0.5*(SOL(j-1,1)+SOL(j+1,1)) - 0.5*courant*(SOL(j+1,1)-SOL(j-1,1));
			end
		SOL(:,1) = SOL(:,2);
		SOLPLOT(:,n+1) = SOL(NT+1:NT+NX+1,1);
        end
	
		xx = linspace(I(1),I(2),NX+1);
        
		time = ones(NX+1,1)*linspace(0,T,NT+1);
		space = linspace(I(2),I(1),NX+1)'*ones(1,NT+1);
        plot(xx,SOLPLOT(:,1),xx,SOLPLOT(:,NT+1),xx,exact(xx,T));
        xlabel('x'); ylabel('u'); legend('initial', 'Lax-Friedrichs','exact');
        title(['Lax-Friedrichs for courant = ',num2str(courant)]);
        pause(0.5);
		
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Lax-Wendroff
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if flag==3       
        NT=TT(1);
        NX=XX(1);
        		
		dt = T/NT;
		dx = (I(2)-I(1))/NX;
		% lambda = dt/dx;
        meshrat=dt/dx;
        courant=a*dt/dx
		
		% Initial conditions
		SOL = zeros(NX+2*NT+1,2);
		SOLPLOT = zeros(NX+1,NT+1);
		for j = 1:NX+2*NT+1
			SOL(j,1) = u0(I(2)+(NT+1-j)*dx);
		end
		SOLPLOT(:,1) = SOL(NT+1:NT+NX+1,1);
		
		% Finite Difference-Scheme: Lax-Wendroff
		for n = 1:NT
			for j = 1+n:NX+2*NT+1-n
				% SOL(j,2) = SOL(j,1) - 0.5*lambda*a*(SOL(j-1,1) - SOL(j+1,1))...
% 						+  0.5*(lambda*a)^2*(SOL(j-1,1)-2*SOL(j,1)+SOL(j+1,1));
                SOL(j,2) = SOL(j,1) - 0.5*courant*(SOL(j+1,1) - SOL(j-1,1))...
                    +  0.5*(courant)^2*(SOL(j-1,1)-2*SOL(j,1)+SOL(j+1,1));
           %  SOL(j,2) = 0.5*(SOL(j-1,1)+SOL(j+1,1)) - 0.5*courant*(SOL(j+1,1)-SOL(j-1,1));
			end
		SOL(:,1) = SOL(:,2);
		SOLPLOT(:,n+1) = SOL(NT+1:NT+NX+1,1);
        end
	
		xx = linspace(I(1),I(2),NX+1);
        
		time = ones(NX+1,1)*linspace(0,T,NT+1);
		space = linspace(I(2),I(1),NX+1)'*ones(1,NT+1);
        plot(xx,SOLPLOT(:,1),xx,SOLPLOT(:,NT+1),xx,exact(xx,T));
        xlabel('x'); ylabel('u'); legend('initial', 'Lax-Wendroff','exact');
        title(['Lax-Wendroff for courant = ',num2str(courant)]);
        pause(0.5);
		
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Upwind
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if flag==4       
        NT=TT(1);
        NX=XX(1);
        		
		dt = T/NT;
		dx = (I(2)-I(1))/NX;
		% lambda = dt/dx;
        meshrat=dt/dx;
        courant=a*dt/dx
		
		% Initial conditions
		SOL = zeros(NX+2*NT+1,2);
		SOLPLOT = zeros(NX+1,NT+1);
		for j = 1:NX+2*NT+1
			SOL(j,1) = u0(I(2)+(NT+1-j)*dx);
		end
		SOLPLOT(:,1) = SOL(NT+1:NT+NX+1,1);
		
		% Finite Difference-Scheme: Upwind
		for n = 1:NT
			for j = 1+n:NX+2*NT+1-n
				% SOL(j,2) = SOL(j,1) - 0.5*lambda*a*(SOL(j-1,1) - SOL(j+1,1))...
% 						+ 	0.5*lambda*abs(a)*(SOL(j-1,1)-2*SOL(j,1)+SOL(j+1,1));
                SOL(j,2) = SOL(j,1) - 0.5*courant*(SOL(j+1,1) - SOL(j-1,1))...
                    +  0.5*(courant)*sign(a)*(SOL(j-1,1)-2*SOL(j,1)+SOL(j+1,1));
       
			end
		SOL(:,1) = SOL(:,2);
		SOLPLOT(:,n+1) = SOL(NT+1:NT+NX+1,1);
        end
	
		xx = linspace(I(1),I(2),NX+1);
        
		time = ones(NX+1,1)*linspace(0,T,NT+1);
		space = linspace(I(2),I(1),NX+1)'*ones(1,NT+1);
        plot(xx,SOLPLOT(:,1),xx,SOLPLOT(:,NT+1),xx,exact(xx,T));
        xlabel('x'); ylabel('u'); legend('initial', 'Upwind','exact');
        title(['Upwind for courant = ',num2str(courant)]);
        pause(0.5);
		
end


