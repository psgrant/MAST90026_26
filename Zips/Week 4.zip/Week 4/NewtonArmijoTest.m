%  NewtonArmijoTest

tol=[1.e-10 1.e-10]; parms = [100];

% first a case where Newton converges

x=1;
[result,  it_hist]=NewtonResid(x,'atan','atandash',tol,parms);
disp(' Newton with a good initial guess')
it_hist

% now start from a worse initial guess

x=10;
[result,  it_hist]=NewtonResid(x,'atan','atandash',tol,parms);
disp(' Newton with a worse initial guess')
it_hist

% now try damped newton iteration ..

x=10;
[result,  it_hist]=NewtonArmijo(x,'atan','atandash',tol,parms);
disp(' Newton-Armijo')
it_hist