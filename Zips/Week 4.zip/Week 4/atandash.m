function y = atandash(x)

y = 1./(1 + x.^2);