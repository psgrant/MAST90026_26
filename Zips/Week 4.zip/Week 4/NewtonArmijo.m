  function [sol, it_hist, ierr] = NewtonArmijo(x,f,fdash,tol,parms)
% Newton solver, globally convergent 
% solver for f(x) = 0
%
% adapted from nsol.m, nsola.m by C.T.Kelley (1997) by SLC 16/3/2007.
%
% Newton-Armijo iteration
% Parabolic line search via three point interpolation.
%
% function [sol, it_hist, ierr] = NewtonArmijo(x,f,fdash,tol,parms)
%
% inputs:
%     initial iterate = x
%	  function = f
%        f is a string that names a continuous function  f(x) of a single variable.
%        f can also be a function handle
%     derivative = fdash
%        fdash is a string that names the derivative function f'(x)
%     tol = [atol, rtol] relative/absolute
%			error tolerances
%	  parms = [maxit]
%			maxit = maximum number of iterations
%				default = 40
%
% output:
%	sol = solution
%	it_hist =  residuals for the iteration
%	ierr = 0 upon successful termination
%	ierr = 1 if  after maxit iterations
%             the termination criterion is not satisfied
%   ierr = 2 failure in the line search. The iteration
%             is terminated if too many steplength reductions
%             are taken.
%
%
% internal parameter:
%       debug = turns on/off iteration statistics display as
%               the iteration progresses
%       alpha = 1.d-4, parameter to measure sufficient decrease
%
%       sigma0 = .1, sigma1=.5, safeguarding bounds for the linesearch
%
%       maxarm = 50, maximum number of steplength reductions before
%                    failure is reported
%
% Requires dirder.m, parab3p.m, 
%
%
% Example: x=10; tol=[1.e-10 1.e-10]; parms = [100];
%       [result, errs, it_hist]=NewtonArmijo(x,'atan','atandash',tol,parms);
%       result


format long e
%
% set the debug parameter, 1 turns display on, otherwise off
%
debug=0;
%
% initialize it_hist, ierr, and set the iteration parameters
%
% set alpha, sigma0, sigma1, maxarm, and restart_limit
%
alpha = 1.d-4; sigma0=.1; sigma1=.5; maxarm = 50; 

ierr = 0;
maxit=40;
if nargin == 5
maxit=parms(1); 
end
if nargin <= 3
    tol = [0 eps];
end
rtol=tol(2); atol=tol(1);
if nargin<3 
    disp('Must specify 2 functions and an interval.');
    ierr=1;
    return
end
it_hist=[];
itc=0;
% change stopping criterion to residual
f0=feval(f,x);
fnrm=norm(f0,inf);
it_hist(itc+1,1)=fnrm; it_hist(itc+1,2)=0; it_hist(itc+1,3)=0;
fnrmo=1;
stop_tol=atol + rtol*fnrm;
outstat(itc+1, :) = [itc fnrm x ];
%
% main iteration loop
%
while(fnrm > stop_tol & itc < maxit)
   % outstat(itc+1, :) = [itc  x f ];
   itc=itc+1;
   % Newton step
   fd   = feval(fdash,x);
   step = -f0/fd;
   % xt = x+step; % full Newton step
   % ft   = feval(f,xt);
   % nft=norm(ft,inf);
   %
%   The line search starts here.
%
    xold=x;
    lambda=1; lamm=1; lamc=lambda; iarm=0;
    xt = x + lambda*step;
    ft=feval(f,xt);
    nft=norm(ft); nf0=norm(f0); ff0=nf0*nf0; ffc=nft*nft; ffm=nft*nft;
    while nft >= (1 - alpha*lambda) * nf0;
%
%   apply the three point parabolic model
%
        if iarm == 0
            lambda=sigma1*lambda; 
        else
            lambda=parab3p(lamc, lamm, ff0, ffc, ffm); 
        end
%
% update x; keep the books on lambda
%
        xt=x+lambda*step;
        lamm=lamc;
        lamc=lambda;
%
% keep the books on the function norms
%
        ft=feval(f,xt);
        nft=norm(ft);
        ffm=ffc;
        ffc=nft*nft;
        iarm=iarm+1;
        if iarm > maxarm
            disp(' Armijo failure, too many reductions ');
            ierr=2;
            disp(outstat)
            it_hist=it_histx(1:itc+1,:);
            sol=xold;
            return;
        end
    end
   x=xt;
   f0=ft;
   fnrm=norm(f0,inf);
   it_hist(itc+1,1)=fnrm;
   rat=fnrm/fnrmo;
   outstat(itc+1, :) = [itc fnrm  x ];
   if debug==1
        disp(outstat(itc+1,:))
    end
    
end
sol = x;
if debug==1
    disp(outstat)
end
%
% on failure, set the error flag
%
if itc >= maxit
    ierr = 1;
end