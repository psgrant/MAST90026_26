% Chandrasekhar H equation, from Kelley p. 87.
function  Chandra()

close all;
global c N mu
N=200; c = 0.9;
% change c to 0.99, 0.999, 0.9999 to see difft behaviour of hybrid
% chord method  is always faster for this problem!

x = ones(N,1);
mu = (1:N)-0.5;mu=mu';

tol=[1.d-6, 1.d-6]; 
params=[100, 1, 0];
tic;
 [result, errs, it_hist] = nsol(x, 'Hfun', tol, params);
 tNewton=toc
 result;
 semilogy(errs)
 hold on
 params=[100, -1, 1];
tic;
 [result, errs, it_hist] = nsol(x, 'Hfun', tol, params);
 tChord=toc
 result;
 semilogy(errs,'r')
 hold on
 params=[100, 2, 1];
tic;
 [result, errs, it_hist] = nsol(x, 'Hfun', tol, params);
 tSham2=toc
 result;
 semilogy(errs,'g')
 hold on
 % params=[40, 2, 1];
tic;
 [result, errs, it_hist] = nsol(x, 'Hfun', tol);
 tHybrid=toc
 result;
 semilogy(errs,'x')
 % --------------------- 
legend('Newton','chord','Shamanskii m=2', 'hybrid (Kelley)');