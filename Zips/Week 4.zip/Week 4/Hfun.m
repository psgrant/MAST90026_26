function y = Hfun(x)
global c N mu       

 B= ones(N,1)*x'./(mu*ones(1,N)+ones(N,1)*mu');

 y = x-1./(1-(c/2/N)*mu.*sum(B,2));

