%% Sparse Matrices
% This example shows how reordering the rows and columns of a sparse matrix
% can influence the speed and storage requirements of a matrix operation.

% Copyright 1984-2012 The MathWorks, Inc.
% $Revision: 5.18.4.9 $ $Date: 2012/05/15 14:18:00 $
clear 
close all

%% Visualizing a Sparse Matrix
% A SPY plot shows the nonzero elements in a matrix.
% 
% This spy plot shows a SPARSE symmetric positive definite matrix derived from 
% a portion of the Harwell-Boeing test matrix "west0479", a matrix describing 
% connections in a model of a diffraction column in a chemical plant.

%%
% The data is stored in the file AIRFOIL.MAT.  It holds 4253 pairs of (x,y)
% coordinates of the mesh points.  It also holds an array of 12,289 pairs of
% indices, (i,j), specifying connections between the mesh points.

load airfoil

%% The Finite Element Mesh
% First, scale x and y by 2^(-32) to bring them into the range [0,1].  Then
% form the sparse adjacency matrix and make it positive definite.

% Scaling x and y
x = pow2(x,-32); 
y = pow2(y,-32);

% Forming the sparse adjacency matrix and making it positive definite
n = max(max(i),max(j));
A = sparse(i,j,-1,n,n);
A = A + A';
d = abs(sum(A)) + 1;
S = A + diag(sparse(d));

% load('west0479.mat')
% A = west0479;
% S = A * A' + speye(size(A));
pct = 100 / numel(A);

clf; spy(S), title('A Sparse Symmetric Matrix')
nz = nnz(S);
xlabel(sprintf('nonzeros=%d (%.3f%%)',nz,nz*pct));


%% Computing the Cholesky Factor
% Now we compute the Cholesky factor L, where S=L*L'. Notice that L contains
% MANY more nonzero elements than the unfactored S, because the computation of
% the Cholesky factorization creates "fill-in" nonzeros.  This slows down the
% algorithm and increases storage cost.

tic, L = chol(S)'; t(1) = toc;
spy(L), title('Cholesky decomposition of S')
nc(1) = nnz(L);
xlabel(sprintf('nonzeros=%d (%.2f%%)   time=%.2f sec',nc(1),nc(1)*pct,t(1)));


%% Reordering to Speed Up the Calculation
% By reordering the rows and columns of a matrix, it may be possible to reduce
% the amount of fill-in created by factorization, thereby reducing time and 
% storage cost.
% 
% We will now try three different orderings supported by MATLAB(R).
%
% * reverse Cuthill-McKee
% * column count
% * minimum degree


%% Using the Reverse Cuthill-McKee
% The SYMRCM command uses the reverse Cuthill-McKee reordering algorithm to 
% move all nonzero elements closer to the diagonal, reducing the "bandwidth" of
% the original matrix.

p = symrcm(S);
spy(S(p,p)), title('S(p,p) after Cuthill-McKee ordering')
nz = nnz(S);
xlabel(sprintf('nonzeros=%d (%.3f%%)',nz,nz*pct));

%%
% The fill-in produced by Cholesky factorization is confined to the band, so 
% that factorization of the reordered matrix takes less time and less storage.

tic, L = chol(S(p,p))'; t(2) = toc;
spy(L), title('chol(S(p,p)) after Cuthill-McKee ordering')
nc(2) = nnz(L);
xlabel(sprintf('nonzeros=%d (%.2f%%)   time=%.2f sec', nc(2),nc(2)*pct,t(2)));


%% Using Column Count
% The COLPERM command uses the column count reordering algorithm to move rows
% and columns with higher nonzero count towards the end of the matrix.

q = colperm(S);
spy(S(q,q)), title('S(q,q) after column count ordering')
nz = nnz(S);
xlabel(sprintf('nonzeros=%d (%.3f%%)',nz,nz*pct));

%%
% For this example, the column count ordering actually increases the time
% and storage for Cholesky factorization. 

tic, L = chol(S(q,q))'; t(3) = toc;
spy(L), title('chol(S(q,q)) after column count ordering')
nc(3) = nnz(L);
xlabel(sprintf('nonzeros=%d (%.2f%%)   time=%.2f sec',nc(3),nc(3)*pct,t(3)));


%% Using Minimum Degree
% The SYMAMD command uses the approximate minimum degree algorithm (a powerful 
% graph-theoretic technique) to produce large blocks of zeros in the matrix.

r = symamd(S);
spy(S(r,r)), title('S(r,r) after minimum degree ordering')
nz = nnz(S);
xlabel(sprintf('nonzeros=%d (%.3f%%)',nz,nz*pct));

%%
% The blocks of zeros produced by the minimum degree algorithm are preserved
% during the Cholesky factorization.  This can significantly reduce time and
% storage costs.

tic, L = chol(S(r,r))'; t(4) = toc;
spy(L), title('chol(S(r,r)) after minimum degree ordering')
nc(4) = nnz(L);
xlabel(sprintf('nonzeros=%d (%.2f%%)   time=%.2f sec',nc(4),nc(4)*pct,t(4)));


%% Summarizing the Results

labels={'original','Cuthill-McKee','column count','min degree'};

subplot(2,1,1)
bar(nc*pct)
title('Nonzeros after Cholesky factorization')
ylabel('Percent');
set(gca,'xticklabel',labels)

subplot(2,1,2)
bar(t)
title('Time to complete Cholesky factorization')
ylabel('Seconds');
set(gca,'xticklabel',labels)


%displayEndOfDemoMessage(mfilename)
