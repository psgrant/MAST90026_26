 %% Finite Difference Laplacian on a square
% This demo illustrates the computation and representation of the finite
% difference Laplacian on a square.
%

%% The domain
% For this example, NUMGRID numbers points within a square domain.  The SPY
% function is a very useful tool for visualizing the pattern of non-zero
% elements in a given matrix.

clc
close all
% echo on
R = 'B'; % Other possible shapes include L,N,C,D,A,H,B
% Generate and display the grid.
n = 20;
G = numgrid(R,n)
% Number of interior points
N = sum(G(:)>0)

disp(' Notice the ordering from top to bottom,left to right');
disp('Hit key to continue');
pause
figure(1)
spy(G)
title('A finite difference grid')
%figure(1)
%% The discrete Laplacian
% Use DELSQ to generate the discrete Laplacian.  The SPY function gives a
% graphical feel of the population of the matrix.

D = delsq(G)
nz=nnz(D);sparsity=nz/N^2*100;
disp(sprintf('sparsity = %6.2f %%',sparsity));

disp('here D is shown in its sparse representation');
disp('Hit key to continue');
pause
figure(2)
spy(D)
title('The 5-point Laplacian with natural ordering')


DD=full(D)
disp('here D is shown in a full representation');
disp('Hit key to continue');
pause

% for an alternative ordering on the same geometry, use nested dissection
R = 'N'; % Other possible shapes include L,N,C,D,A,H,B
% Generate and display the grid.
n2 = 10;
G2 = numgrid(R,n2)
disp(' A different ordering of points');
disp('Hit key to continue');
pause

D2 = delsq(G2);
figure(3)
spy(D2)
title('The 5-point Laplacian with nested dissection ordering')
disp('Hit key to continue');
pause
%% The Dirichlet boudary value problem
% Finally, we solve the Dirichlet boundary value problem for the sparse linear
% system.  The problem is setup as follows:
%
%    delsq(u) = 1 in the interior,
%    u = 0 on the boundary.

disp('now solve Laplace''s equation using natural ordering');

rhs = ones(N,1); % should really be h^2*ones(N,1)

    u = D\rhs % This is used for R=='S' as in this example
    
    disp('Note this is a vector representing the solution');
    disp(' Now map it back to xy coordinates');

% Matlab uses direct sparse solvers, nased on graph theoretic techniques

%% The solution
% Map the solution onto the grid and show it as a contour map.

U = G;
U(G>0) = full(u(G(G>0)))
figure(4)
clabel(contour(U));
prism
axis square ij
title('Solution of Laplace''s equation')
disp('Solution as a contour plot');
disp('Hit key to continue');
pause
%% 
% Now show the solution as a mesh plot.
figure(5)
colormap((cool+1)/2);
mesh(U)
axis([0 n 0 n 0 max(max(U))])
axis square ij
title('Solution of Laplace''s equation')
disp('Solution as a mesh plot');

% Now show the solution as a surface.
figure(6)
% colormap((cool+1)/2);
surfl(U)
shading flat; colormap hot;
axis([0 n 0 n 0 max(max(U))])
axis square ij
title('Solution of Laplace''s equation')
disp('Solution as a surface plot');
