function fEl = elem_load(hl,fl,fl1)
    fEl = (hl/2)*[fl; fl1];
end

