function KEl = elem_mass(hl, ql, ql1)
    KEl = (hl/2)*[ql, 0; 0, ql1];
end

