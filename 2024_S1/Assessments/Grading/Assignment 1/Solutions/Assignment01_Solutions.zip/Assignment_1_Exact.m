function u = Assignment1_Exact(x)
    u = (1/8)*(3*sin(x) - 5*sin(3*x));
end